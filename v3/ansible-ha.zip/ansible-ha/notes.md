TESTING ON MINIKUBE
Step 1: Start Minikube with NodePort range

minikube start --driver=virtualbox

Step 2: Apply playbooks

ansible-playbook -i inventory/hosts.ini playbooks/haproxy_keepalived.yml
ansible-playbook -i inventory/hosts.ini playbooks/helm_install.yml

Step 3: Test HA

Access http://192.168.1.100/ — the VIP

Use ip addr and systemctl stop keepalived to simulate failover
Use curl or browser to confirm service continues via the second node

